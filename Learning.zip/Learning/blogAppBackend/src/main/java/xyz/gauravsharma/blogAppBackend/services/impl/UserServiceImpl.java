package xyz.gauravsharma.blogAppBackend.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import xyz.gauravsharma.blogAppBackend.converters.UserDtoToUserConverter;
import xyz.gauravsharma.blogAppBackend.converters.UserToUserDtoConverter;
import xyz.gauravsharma.blogAppBackend.exceptions.ResourceNotFoundException;
import xyz.gauravsharma.blogAppBackend.models.User;
import xyz.gauravsharma.blogAppBackend.payloads.UserDto;
import xyz.gauravsharma.blogAppBackend.repositories.UserRepo;
import xyz.gauravsharma.blogAppBackend.services.UserService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private UserToUserDtoConverter userToUserDtoConverter;

    @Autowired
    private UserDtoToUserConverter userDtoToUserConverter;

    @Override
    public UserDto createUser(UserDto userDto) {
        return userToUserDtoConverter.convert(userRepo.save(userDtoToUserConverter.convert(userDto)));
    }

    @Override
    public UserDto getUserById(Integer userId) {
        User user = userRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User", "id", userId.toString()));
        return userToUserDtoConverter.convert(user);
    }

    @Override
    public UserDto updateUser(UserDto userDto, Integer userId) {
        User user = userRepo.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User", "id", userId.toString()));
        user.setName(userDto.getName());
        user.setEmail(userDto.getEmail());
        user.setPassword(userDto.getPassword());
        user.setAbout(userDto.getAbout());

        return userToUserDtoConverter.convert(userRepo.save(user));
    }

    @Override
    public List<UserDto> getAllUsers() {
        return userRepo.findAll().stream().map(user -> userToUserDtoConverter.convert(user)).collect(Collectors.toList());
    }

    @Override
    public void deleteUser(Integer userId) {
        userRepo.deleteById(userId);
    }
}
