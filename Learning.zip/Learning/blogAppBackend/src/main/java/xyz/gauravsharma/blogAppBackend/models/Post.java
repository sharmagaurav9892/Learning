package xyz.gauravsharma.blogAppBackend.models;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Data
public class Post {

    private int id;
    private String title;
    private String content;
    private String imageId;
}