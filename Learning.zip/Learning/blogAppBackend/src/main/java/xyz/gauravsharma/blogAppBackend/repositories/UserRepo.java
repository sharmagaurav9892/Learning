package xyz.gauravsharma.blogAppBackend.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import xyz.gauravsharma.blogAppBackend.models.User;


public interface UserRepo extends JpaRepository<User,Integer> {
}
