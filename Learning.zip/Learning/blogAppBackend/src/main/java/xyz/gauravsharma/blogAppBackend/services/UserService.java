package xyz.gauravsharma.blogAppBackend.services;

import xyz.gauravsharma.blogAppBackend.payloads.UserDto;

import java.util.List;

public interface UserService {

    UserDto createUser(UserDto userDto);

    UserDto getUserById(Integer userId);

    UserDto updateUser(UserDto userDto, Integer userId);

    List<UserDto> getAllUsers();

    void deleteUser(Integer userId);
}
