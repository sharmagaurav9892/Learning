package xyz.gauravsharma.blogAppBackend.payloads;

import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

@Data
public class UserDto {

    private int userId;

    @NotEmpty
    @Size(min =4, max = 20)
    private String name;

    @Email
    private String email;

    @NotEmpty
    @Size(min =4, max = 12)
    private String password;

    @NotEmpty
    @Size(min =4, max = 20)
    private String about;
}
