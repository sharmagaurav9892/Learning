package xyz.gauravsharma.blogAppBackend.converters;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import xyz.gauravsharma.blogAppBackend.models.User;
import xyz.gauravsharma.blogAppBackend.payloads.UserDto;

@Component
public class UserDtoToUserConverter {

    @Autowired
    private ModelMapper modelMapper;

    public User convert(UserDto userDto) {

        User user = modelMapper.map(userDto,User.class);
        return user;
    }
}
